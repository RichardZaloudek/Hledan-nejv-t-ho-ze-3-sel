const tbxNumber1 = document.getElementById ("tbxNumber1");
const tbxNumber2 = document.getElementById ("tbxNumber2");
const tbxNumber3 = document.getElementById ("tbxNumber3");

const txaResult = document.getElementById ("txaResult");

function hledejMaximum() {
    let cislo1 = Number (tbxNumber1.value);
    let cislo2 = Number (tbxNumber2.value);
    let cislo3 = Number(tbxNumber3.value);
    let maximum = cislo1;
    let kdeVsudeJeMaximum = "1.";
    txaResult.value = cislo1 + cislo2;

    if (cislo2 >= maximum) {
    maximum = cislo2;
    kdeVsudeJeMaximum = "2."; 
    }
else {
    if (cislo2 == maximum) {
    kdeVsudeJeMaximum += "2.";
    }
}

if (cislo3 > maximum) {
    maximum = cislo3;
    kdeVsudeJeMaximum = "3.";
}
else {
    if (cislo3 == maximum) {
    kdeVsudeJeMaximum += "3.";
    }
}

txaResult.value = "Největší číslo je " + maximum;
txaResult.value += "\nA je na pozicích: " + kdeVsudeJeMaximum;
}